-- =======================================================================
-- DIM_PAYMENTS load -- two procedures, same target table, kept in one
-- file per the mentor's guidance on grouping procedures by target
-- table.
--
-- PRC_LOAD_DIM_PAYMENTS (Task 8): full re-scan of BL_3NF.CE_PAYMENT on
-- every run. Techniques used: cursor VARIABLE (refcursor) declared
-- explicitly and opened with OPEN ... FOR SELECT, then driven manually
-- with FETCH / EXIT WHEN NOT FOUND / CLOSE.
--
-- PRC_LOAD_DIM_PAYMENTS_INCR (Task 9): the version actually used by
-- PRC_RUN_ALL_LOADS. Uses a watermark (MTA_LOAD_WATERMARK -- the
-- highest source surrogate key already loaded) so only brand-new
-- payments are read from BL_3NF, instead of a full re-scan every time.
-- This is the project's answer to the "incremental load for at least
-- one table" requirement.
-- Trade-off, stated plainly: this only picks up brand-new payments. If
-- an already-loaded payment's attributes changed in place on BL_3NF,
-- the full-scan PRC_LOAD_DIM_PAYMENTS above would still catch it, this
-- one would not -- that is the price of not re-reading old rows.
-- Both procedures stay callable on their own; PRC_RUN_ALL_LOADS only
-- calls the incremental one, to avoid loading payments twice.
--
-- REVISION (mentor feedback on the source-triplet PR): same fix as
-- PRC_LOAD_DIM_PRODUCTS -- source_system was hardcoded to the constant
-- 'BL_3NF' for every row instead of the real SA_RETAIL/SA_ONLINE origin,
-- so a genuine payment_id collision between sources would have the
-- DISTINCT ON tie-break silently drop one payment and misattribute its
-- transaction to the other. Both procedures below now carry the real
-- source_system through instead of the constant, and DISTINCT ON is
-- dropped from both: CE_PAYMENT already guarantees at most one row per
-- (source_system, payment_id), so once source_system is real (not a
-- shared constant), a retail row and an online row sharing the same
-- payment_id target two DIFFERENT ON CONFLICT keys -- (SA_RETAIL,
-- CE_PAYMENT, payment_id) vs (SA_ONLINE, CE_PAYMENT, payment_id) -- so
-- PRC_LOAD_DIM_PAYMENTS_INCR's "cannot affect row a second time" risk
-- (see its own comment below, now stale) no longer applies either. The
-- matching fix on the fact-load join lives in
-- 09_prc_load_fct_transactions_dd.sql.
-- =======================================================================
CREATE OR REPLACE PROCEDURE bl_cl.prc_load_dim_payments()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts   TIMESTAMP := clock_timestamp();
    c_payments   refcursor;
    v_rec        RECORD;
    v_this       INTEGER;
    v_rows       INTEGER := 0;
BEGIN
    OPEN c_payments FOR
        SELECT payment_id, payment_method, payment_status, payment_risk_score, source_system
        FROM bl_3nf.ce_payment
        WHERE payment_sk <> -1;

    LOOP
        FETCH c_payments INTO v_rec;
        EXIT WHEN NOT FOUND;

        INSERT INTO bl_dm.dim_payments (
            payment_surr_id, payment_src_id, payment_method, payment_status, payment_risk_score,
            insert_dt, update_dt, source_system, source_entity
        ) VALUES (
            nextval('bl_dm.seq_dim_payments'), v_rec.payment_id::VARCHAR(50), v_rec.payment_method,
            v_rec.payment_status, v_rec.payment_risk_score, CURRENT_DATE, CURRENT_DATE, v_rec.source_system, 'CE_PAYMENT'
        )
        ON CONFLICT (source_system, source_entity, payment_src_id) DO UPDATE SET
            payment_method     = EXCLUDED.payment_method,
            payment_status     = EXCLUDED.payment_status,
            payment_risk_score = EXCLUDED.payment_risk_score,
            update_dt          = CURRENT_DATE
        WHERE dim_payments.payment_method     IS DISTINCT FROM EXCLUDED.payment_method
           OR dim_payments.payment_status     IS DISTINCT FROM EXCLUDED.payment_status
           OR dim_payments.payment_risk_score IS DISTINCT FROM EXCLUDED.payment_risk_score;

        GET DIAGNOSTICS v_this = ROW_COUNT;
        v_rows := v_rows + v_this;
    END LOOP;

    CLOSE c_payments;

    CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_PAYMENTS', v_start_ts, v_rows, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_PAYMENTS', v_start_ts, v_rows, 'FAILED', SQLERRM);
        RAISE;
END;
$$;


CREATE TABLE IF NOT EXISTS bl_cl.mta_load_watermark (
    procedure_name VARCHAR(100) NOT NULL,
    last_value     BIGINT       NOT NULL,
    updated_ts     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_mta_load_watermark PRIMARY KEY (procedure_name)
);

CREATE OR REPLACE PROCEDURE bl_cl.prc_load_dim_payments_incr()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts      TIMESTAMP := clock_timestamp();
    v_watermark     BIGINT;
    v_new_watermark BIGINT;
    v_rows          INTEGER := 0;
BEGIN
    SELECT last_value INTO v_watermark
    FROM bl_cl.mta_load_watermark
    WHERE procedure_name = 'PRC_LOAD_DIM_PAYMENTS_INCR';

    IF NOT FOUND THEN
        v_watermark := -1; -- first run: load everything except the -1 default row
    END IF;

    -- REVISION: previously this needed DISTINCT ON (payment_id) as a
    -- correctness requirement, not just a data-quality nicety -- with
    -- source_system hardcoded to the same constant 'BL_3NF' for every
    -- row, a retail row and an online row sharing the same payment_id
    -- both crossing the watermark in one run would ON CONFLICT the same
    -- dim_payments row twice inside one statement, which PostgreSQL
    -- rejects outright ("ON CONFLICT DO UPDATE command cannot affect row
    -- a second time"). Now that source_system carries the real
    -- SA_RETAIL/SA_ONLINE origin, that pair targets two DIFFERENT
    -- conflict keys, so the collision this dedup existed to avoid can no
    -- longer happen -- CE_PAYMENT already guarantees at most one row per
    -- (source_system, payment_id) on its own.
    INSERT INTO bl_dm.dim_payments (
        payment_surr_id, payment_src_id, payment_method, payment_status, payment_risk_score,
        insert_dt, update_dt, source_system, source_entity
    )
    SELECT
        nextval('bl_dm.seq_dim_payments'), src.payment_id::VARCHAR(50), src.payment_method,
        src.payment_status, src.payment_risk_score, CURRENT_DATE, CURRENT_DATE, src.source_system, 'CE_PAYMENT'
    FROM (
        SELECT payment_id, payment_method, payment_status, payment_risk_score, source_system
        FROM bl_3nf.ce_payment
        WHERE payment_sk > v_watermark AND payment_sk <> -1
    ) src
    ON CONFLICT (source_system, source_entity, payment_src_id) DO UPDATE SET
        payment_method     = EXCLUDED.payment_method,
        payment_status     = EXCLUDED.payment_status,
        payment_risk_score = EXCLUDED.payment_risk_score,
        update_dt          = CURRENT_DATE
    WHERE dim_payments.payment_method     IS DISTINCT FROM EXCLUDED.payment_method
       OR dim_payments.payment_status     IS DISTINCT FROM EXCLUDED.payment_status
       OR dim_payments.payment_risk_score IS DISTINCT FROM EXCLUDED.payment_risk_score;

    GET DIAGNOSTICS v_rows = ROW_COUNT;

    SELECT MAX(payment_sk) INTO v_new_watermark FROM bl_3nf.ce_payment WHERE payment_sk <> -1;

    IF v_new_watermark IS NOT NULL THEN
        INSERT INTO bl_cl.mta_load_watermark (procedure_name, last_value, updated_ts)
        VALUES ('PRC_LOAD_DIM_PAYMENTS_INCR', v_new_watermark, clock_timestamp())
        ON CONFLICT (procedure_name) DO UPDATE SET
            last_value = EXCLUDED.last_value,
            updated_ts = EXCLUDED.updated_ts;
    END IF;

    CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_PAYMENTS_INCR', v_start_ts, v_rows, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_PAYMENTS_INCR', v_start_ts, v_rows, 'FAILED', SQLERRM);
        RAISE;
END;
$$;
