-- =======================================================================
-- PRC_LOAD_CE_TRANSACTION
-- Incremental load of the fact table on the 3NF layer (CE_TRANSACTION).
-- Every dimension lookup is a LEFT JOIN with the surrogate key
-- COALESCE'd to -1, and CUSTOMER_SK is resolved "as of" the transaction
-- date (transaction_date BETWEEN cu.start_dt AND cu.end_dt) rather than
-- the customer's currently-active row, so a historical transaction
-- always points at the customer attributes that were true when it
-- happened.
--
-- No cursor is needed here -- a single set-based INSERT ... SELECT ...
-- WHERE NOT EXISTS is the correct shape for a fact table that is pure
-- append (transactions are never updated after the fact).
--
-- NOTE on the date: CE_TRANSACTION stores TRANSACTION_DATE directly as
-- its own column -- there is no DATE_SK / CE_DATE lookup on the 3NF
-- layer, unlike the BL_DM dimensions.
--
-- REVISION -- mentor feedback on the source-triplet PR: every dimension
-- lookup below now also matches on source_system. Required, not
-- optional, now that CE_PRODUCT/CE_STORE/CE_PAYMENT/CE_DELIVERY/
-- CE_CUSTOMER can each hold one row per source sharing the same natural
-- id (see 02_prc_refresh_bl_3nf.sql) -- without this, a transaction's
-- lookup could ambiguously resolve to the wrong source's dimension row.
-- =======================================================================
CREATE OR REPLACE PROCEDURE bl_cl.prc_load_ce_transaction()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts TIMESTAMP := clock_timestamp();
    v_rows     INTEGER := 0;
BEGIN
    INSERT INTO bl_3nf.ce_transaction (
        transaction_sk, transaction_id, customer_sk, product_sk, store_sk, payment_sk, delivery_sk,
        quantity, unit_price, sales_value, discount, cost_price, shipping_cost, total_cost, profit,
        transaction_channel, insert_dt, update_dt, source_system, source_entity, source_id, transaction_date
    )
    SELECT
        nextval('bl_3nf.seq_ce_transaction'),
        t.transaction_id,
        COALESCE(cu.customer_sk, -1),
        COALESCE(pr.product_sk, -1),
        COALESCE(st.store_sk, -1),
        COALESCE(pm.payment_sk, -1),
        COALESCE(dl.delivery_sk, -1),
        t.quantity,
        t.unit_price,
        t.sales_value,
        t.discount,
        t.cost_price,
        COALESCE(t.shipping_cost, 0),
        t.total_cost,
        t.profit,
        t.transaction_channel,
        CURRENT_TIMESTAMP,
        CURRENT_TIMESTAMP,
        t.source_system,
        t.source_entity,
        t.transaction_id::VARCHAR(100),
        t.transaction_date
    FROM (
        SELECT transaction_id, customer_id, product_id, store_id, transaction_date, quantity, unit_price,
               sales_value, discount, cost_price, NULL::NUMERIC(12,2) AS shipping_cost, total_cost, profit,
               transaction_channel, 'SA_RETAIL' AS source_system, 'SRC_RETAIL_SALES' AS source_entity
        FROM sa_retail.src_retail_sales
        UNION ALL
        SELECT transaction_id, customer_id, product_id, store_id, transaction_date, quantity, unit_price,
               sales_value, discount, cost_price, shipping_cost, total_cost, profit,
               transaction_channel, 'SA_ONLINE' AS source_system, 'SRC_ONLINE_SALES' AS source_entity
        FROM sa_online.src_online_sales
    ) t
    LEFT JOIN bl_3nf.ce_customer cu ON cu.customer_id = t.customer_id
                                    AND cu.source_system = t.source_system
                                    AND t.transaction_date BETWEEN cu.start_dt AND cu.end_dt
    LEFT JOIN bl_3nf.ce_product  pr ON pr.product_id  = t.product_id
                                    AND pr.source_system = t.source_system
    LEFT JOIN bl_3nf.ce_store    st ON st.store_id    = t.store_id
                                    AND st.source_system = t.source_system
    LEFT JOIN bl_3nf.ce_payment  pm ON pm.payment_id  = t.transaction_id
                                    AND pm.source_system = t.source_system
    LEFT JOIN bl_3nf.ce_delivery dl ON dl.delivery_id = t.transaction_id::VARCHAR(50)
                                    AND dl.source_system = t.source_system
    WHERE NOT EXISTS (
        SELECT 1 FROM bl_3nf.ce_transaction ct WHERE ct.transaction_id = t.transaction_id
    );

    GET DIAGNOSTICS v_rows = ROW_COUNT;

    CALL bl_cl.prc_log_etl_event('PRC_LOAD_CE_TRANSACTION', v_start_ts, v_rows, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_LOAD_CE_TRANSACTION', v_start_ts, v_rows, 'FAILED', SQLERRM);
        RAISE;
END;
$$;
