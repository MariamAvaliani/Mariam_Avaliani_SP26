-- =======================================================================
-- PRC_LOAD_DIM_PRODUCTS
-- Techniques used: MERGE INTO ... USING (source query) ... -- one
-- set-based statement instead of a row-by-row loop. This is the
-- dimension that satisfies "at least one dimension loaded using merge".
-- Requires PostgreSQL 15+ (MERGE was added in PG 15 -- check
-- `SELECT version();` before running this on a given instance).
-- The WHEN MATCHED AND (...) condition means an unchanged row is
-- skipped entirely (0 rows affected) -- this is what makes the
-- procedure repeatable: run it twice on the same source data and the
-- second run reports 0 rows affected in the log.
-- Source-side lookups use LEFT JOIN (not INNER JOIN) so a product that
-- is somehow missing its subcategory/category still gets loaded with
-- NULLs there instead of silently disappearing from the load.
--
-- REVISION (mentor feedback on the source-triplet PR): matched on
-- (source_system, product_src_id) in the ON clause, not product_src_id
-- alone, and carries the real p.source_system through instead of a
-- hardcoded constant -- same fix as the rest of BL_DM's conformed
-- dimensions (see 09_prc_load_fct_transactions_dd.sql's header note).
-- Matching only on product_src_id would let a genuine cross-source id
-- collision map two different BL_3NF rows onto the same DIM_PRODUCTS
-- target row -- and PostgreSQL's MERGE explicitly forbids one target
-- row being matched twice in a single statement (raises "MERGE command
-- cannot affect row a second time"), so an unqualified ON clause would
-- crash the very first time a real collision showed up in the data,
-- instead of silently misattributing the way the old DISTINCT ON
-- cursor version used to. No DISTINCT ON / dedup step is needed here at
-- all: CE_PRODUCT already guarantees at most one row per (source_system,
-- product_id), so retail and online products under a colliding id load
-- as two separate, correctly-attributed DIM_PRODUCTS rows.
-- =======================================================================
CREATE OR REPLACE PROCEDURE bl_cl.prc_load_dim_products()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts TIMESTAMP := clock_timestamp();
    v_rows     INTEGER := 0;
BEGIN
    MERGE INTO bl_dm.dim_products AS tgt
    USING (
        SELECT
            p.product_id::VARCHAR(50) AS product_src_id,
            p.product_name,
            c.category_name           AS product_category,
            s.subcategory_name        AS product_subcategory,
            p.product_brand,
            p.product_price           AS product_price_amt,
            p.source_system           AS source_system,
            'CE_PRODUCT'::VARCHAR(50) AS source_entity
        FROM bl_3nf.ce_product p
        LEFT JOIN bl_3nf.ce_subcategory s ON s.subcategory_sk = p.subcategory_sk
        LEFT JOIN bl_3nf.ce_category c    ON c.category_sk = s.category_sk
        WHERE p.product_sk <> -1
    ) AS src
    ON tgt.source_system = src.source_system
   AND tgt.product_src_id = src.product_src_id

    WHEN MATCHED AND (
            tgt.product_name        IS DISTINCT FROM src.product_name
         OR tgt.product_category    IS DISTINCT FROM src.product_category
         OR tgt.product_subcategory IS DISTINCT FROM src.product_subcategory
         OR tgt.product_brand       IS DISTINCT FROM src.product_brand
         OR tgt.product_price_amt   IS DISTINCT FROM src.product_price_amt
    ) THEN
        UPDATE SET
            product_name        = src.product_name,
            product_category    = src.product_category,
            product_subcategory = src.product_subcategory,
            product_brand       = src.product_brand,
            product_price_amt   = src.product_price_amt,
            update_dt           = CURRENT_DATE,
            source_entity        = src.source_entity

    WHEN NOT MATCHED THEN
        INSERT (product_surr_id, product_src_id, product_name, product_category, product_subcategory,
                product_brand, product_price_amt, insert_dt, update_dt, source_system, source_entity)
        VALUES (nextval('bl_dm.seq_dim_products'), src.product_src_id, src.product_name, src.product_category,
                src.product_subcategory, src.product_brand, src.product_price_amt,
                CURRENT_DATE, CURRENT_DATE, src.source_system, src.source_entity);

    GET DIAGNOSTICS v_rows = ROW_COUNT;

    CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_PRODUCTS', v_start_ts, v_rows, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_PRODUCTS', v_start_ts, v_rows, 'FAILED', SQLERRM);
        RAISE;
END;
$$;
