-- =======================================================================
-- PRC_LOAD_DIM_STORES
-- Techniques used: cursor FOR loop over a join query, plain (static)
-- upsert. Kept static (no EXECUTE) on purpose, as a contrast to
-- PRC_LOAD_DIM_PRODUCTS -- both approaches are valid PL/pgSQL, dynamic
-- SQL is not required everywhere.
--
-- REVISION (mentor feedback on the source-triplet PR): same fix as
-- PRC_LOAD_DIM_PRODUCTS -- source_system was hardcoded to the constant
-- 'BL_3NF' for every row instead of the real SA_RETAIL/SA_ONLINE origin,
-- so a genuine store_id collision between sources would have the
-- DISTINCT ON tie-break silently drop one store and misattribute its
-- transactions to the other. Now carries the real st.source_system
-- through; DISTINCT ON is no longer needed since CE_STORE already
-- guarantees at most one row per (source_system, store_id). The
-- matching fix on the fact-load join lives in
-- 09_prc_load_fct_transactions_dd.sql.
-- =======================================================================
CREATE OR REPLACE PROCEDURE bl_cl.prc_load_dim_stores()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts TIMESTAMP := clock_timestamp();
    v_rec      RECORD;
    v_this     INTEGER;
    v_rows     INTEGER := 0;
BEGIN
    FOR v_rec IN
        SELECT
            st.store_id, st.store_location, st.store_type, r.region_name, c.country_name, st.source_system
        FROM bl_3nf.ce_store st
        JOIN bl_3nf.ce_region  r ON r.region_sk = st.region_sk
        JOIN bl_3nf.ce_country c ON c.country_sk = r.country_sk
        WHERE st.store_sk <> -1
    LOOP
        INSERT INTO bl_dm.dim_stores (
            store_surr_id, store_src_id, store_location, store_type, store_region, store_country,
            insert_dt, update_dt, source_system, source_entity
        ) VALUES (
            nextval('bl_dm.seq_dim_stores'), v_rec.store_id::VARCHAR(50), v_rec.store_location, v_rec.store_type,
            v_rec.region_name, v_rec.country_name, CURRENT_DATE, CURRENT_DATE, v_rec.source_system, 'CE_STORE'
        )
        ON CONFLICT (source_system, source_entity, store_src_id) DO UPDATE SET
            store_location = EXCLUDED.store_location,
            store_type     = EXCLUDED.store_type,
            store_region   = EXCLUDED.store_region,
            store_country  = EXCLUDED.store_country,
            update_dt      = CURRENT_DATE
        WHERE dim_stores.store_location IS DISTINCT FROM EXCLUDED.store_location
           OR dim_stores.store_type     IS DISTINCT FROM EXCLUDED.store_type
           OR dim_stores.store_region   IS DISTINCT FROM EXCLUDED.store_region
           OR dim_stores.store_country  IS DISTINCT FROM EXCLUDED.store_country;

        GET DIAGNOSTICS v_this = ROW_COUNT;
        v_rows := v_rows + v_this;
    END LOOP;

    CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_STORES', v_start_ts, v_rows, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_STORES', v_start_ts, v_rows, 'FAILED', SQLERRM);
        RAISE;
END;
$$;
