-- =======================================================================
-- DIM_PAYMENTS load -- two procedures, same target table, kept in one
-- file per the mentor's guidance on grouping procedures by target
-- table.
--
-- PRC_LOAD_DIM_PAYMENTS (Task 8): full re-scan of BL_3NF.CE_PAYMENT on
-- every run. Techniques used: cursor VARIABLE (refcursor) declared
-- explicitly and opened with OPEN ... FOR SELECT, then driven manually
-- with FETCH / EXIT WHEN NOT FOUND / CLOSE.
--
-- PRC_LOAD_DIM_PAYMENTS_INCR (Task 9): the version actually used by
-- PRC_RUN_ALL_LOADS. Uses a watermark (MTA_LOAD_WATERMARK -- the
-- highest source surrogate key already loaded) so only brand-new
-- payments are read from BL_3NF, instead of a full re-scan every time.
-- This is the project's answer to the "incremental load for at least
-- one table" requirement.
-- Trade-off, stated plainly: this only picks up brand-new payments. If
-- an already-loaded payment's attributes changed in place on BL_3NF,
-- the full-scan PRC_LOAD_DIM_PAYMENTS above would still catch it, this
-- one would not -- that is the price of not re-reading old rows.
-- Both procedures stay callable on their own; PRC_RUN_ALL_LOADS only
-- calls the incremental one, to avoid loading payments twice.
-- =======================================================================
CREATE OR REPLACE PROCEDURE bl_cl.prc_load_dim_payments()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts   TIMESTAMP := clock_timestamp();
    c_payments   refcursor;
    v_rec        RECORD;
    v_this       INTEGER;
    v_rows       INTEGER := 0;
BEGIN
    OPEN c_payments FOR
        SELECT payment_id, payment_method, payment_status, payment_risk_score
        FROM bl_3nf.ce_payment
        WHERE payment_sk <> -1;

    LOOP
        FETCH c_payments INTO v_rec;
        EXIT WHEN NOT FOUND;

        INSERT INTO bl_dm.dim_payments (
            payment_surr_id, payment_src_id, payment_method, payment_status, payment_risk_score,
            insert_dt, update_dt, source_system, source_entity
        ) VALUES (
            nextval('bl_dm.seq_dim_payments'), v_rec.payment_id::VARCHAR(50), v_rec.payment_method,
            v_rec.payment_status, v_rec.payment_risk_score, CURRENT_DATE, CURRENT_DATE, 'BL_3NF', 'CE_PAYMENT'
        )
        ON CONFLICT (payment_src_id) DO UPDATE SET
            payment_method     = EXCLUDED.payment_method,
            payment_status     = EXCLUDED.payment_status,
            payment_risk_score = EXCLUDED.payment_risk_score,
            update_dt          = CURRENT_DATE
        WHERE dim_payments.payment_method     IS DISTINCT FROM EXCLUDED.payment_method
           OR dim_payments.payment_status     IS DISTINCT FROM EXCLUDED.payment_status
           OR dim_payments.payment_risk_score IS DISTINCT FROM EXCLUDED.payment_risk_score;

        GET DIAGNOSTICS v_this = ROW_COUNT;
        v_rows := v_rows + v_this;
    END LOOP;

    CLOSE c_payments;

    CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_PAYMENTS', v_start_ts, v_rows, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_PAYMENTS', v_start_ts, v_rows, 'FAILED', SQLERRM);
        RAISE;
END;
$$;


CREATE TABLE IF NOT EXISTS bl_cl.mta_load_watermark (
    procedure_name VARCHAR(100) NOT NULL,
    last_value     BIGINT       NOT NULL,
    updated_ts     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_mta_load_watermark PRIMARY KEY (procedure_name)
);

CREATE OR REPLACE PROCEDURE bl_cl.prc_load_dim_payments_incr()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts      TIMESTAMP := clock_timestamp();
    v_watermark     BIGINT;
    v_new_watermark BIGINT;
    v_rows          INTEGER := 0;
BEGIN
    SELECT last_value INTO v_watermark
    FROM bl_cl.mta_load_watermark
    WHERE procedure_name = 'PRC_LOAD_DIM_PAYMENTS_INCR';

    IF NOT FOUND THEN
        v_watermark := -1; -- first run: load everything except the -1 default row
    END IF;

    INSERT INTO bl_dm.dim_payments (
        payment_surr_id, payment_src_id, payment_method, payment_status, payment_risk_score,
        insert_dt, update_dt, source_system, source_entity
    )
    SELECT
        nextval('bl_dm.seq_dim_payments'), p.payment_id::VARCHAR(50), p.payment_method,
        p.payment_status, p.payment_risk_score, CURRENT_DATE, CURRENT_DATE, 'BL_3NF', 'CE_PAYMENT'
    FROM bl_3nf.ce_payment p
    WHERE p.payment_sk > v_watermark AND p.payment_sk <> -1
    ON CONFLICT (payment_src_id) DO UPDATE SET
        payment_method     = EXCLUDED.payment_method,
        payment_status     = EXCLUDED.payment_status,
        payment_risk_score = EXCLUDED.payment_risk_score,
        update_dt          = CURRENT_DATE
    WHERE dim_payments.payment_method     IS DISTINCT FROM EXCLUDED.payment_method
       OR dim_payments.payment_status     IS DISTINCT FROM EXCLUDED.payment_status
       OR dim_payments.payment_risk_score IS DISTINCT FROM EXCLUDED.payment_risk_score;

    GET DIAGNOSTICS v_rows = ROW_COUNT;

    SELECT MAX(payment_sk) INTO v_new_watermark FROM bl_3nf.ce_payment WHERE payment_sk <> -1;

    IF v_new_watermark IS NOT NULL THEN
        INSERT INTO bl_cl.mta_load_watermark (procedure_name, last_value, updated_ts)
        VALUES ('PRC_LOAD_DIM_PAYMENTS_INCR', v_new_watermark, clock_timestamp())
        ON CONFLICT (procedure_name) DO UPDATE SET
            last_value = EXCLUDED.last_value,
            updated_ts = EXCLUDED.updated_ts;
    END IF;

    CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_PAYMENTS_INCR', v_start_ts, v_rows, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_PAYMENTS_INCR', v_start_ts, v_rows, 'FAILED', SQLERRM);
        RAISE;
END;
$$;
