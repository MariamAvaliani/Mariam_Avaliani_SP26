-- =======================================================================
-- FCT_TRANSACTIONS_DD load -- two procedures, same target table, kept in
-- one file per the mentor's guidance on grouping procedures by target
-- table (this was the mentor's own example: "if you have like 2
-- procedures that manage the load for your fact table, since this
-- entire partitioning thing, you may have more than one procedure
-- handling this, just create a single file and put all the logic").
--
-- PRC_MANAGE_FCT_PARTITIONS keeps the rolling window of monthly RANGE
-- partitions attached; PRC_LOAD_FCT_TRANSACTIONS_DD calls it first and
-- then inserts the new fact rows.
-- =======================================================================

-- =======================================================================
-- PRC_MANAGE_FCT_PARTITIONS
-- Keeps BL_DM.FCT_TRANSACTIONS_DD's rolling window of p_window_months
-- (default 3) attached, using CREATE TABLE ... (LIKE ... INCLUDING ALL)
-- + ALTER TABLE ... ATTACH PARTITION for months entering the window, and
-- ALTER TABLE ... DETACH PARTITION (never DROP) for months rolling out.
--
-- "Current month" is not CURRENT_DATE -- it is the latest month that
-- actually has data, either already loaded (BL_DM) or waiting to be
-- loaded (BL_3NF). This is deliberate: the source files for this project
-- are a fixed historical dataset, not a live daily feed, so anchoring the
-- window to the system clock would immediately roll every partition out
-- of the window the moment CURRENT_DATE is later than the data itself.
-- =======================================================================
CREATE OR REPLACE PROCEDURE bl_cl.prc_manage_fct_partitions(p_window_months INTEGER DEFAULT 3)
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts     TIMESTAMP := clock_timestamp();
    v_current_month DATE;
    v_cutoff        DATE;
    v_month         DATE;
    v_part_name     TEXT;
    v_created       TEXT := '';
    v_detached      TEXT := '';
    v_created_count INTEGER := 0;
    v_detached_count INTEGER := 0;
    v_count         INTEGER := 0;
    v_rec           RECORD;
    v_message       TEXT;   -- unbounded on purpose: MTA_ETL_LOG.MESSAGE is VARCHAR(1000),
                             -- but assigning straight into a VARCHAR(1000) variable would hit
                             -- the same "value too long" error at the assignment itself, before
                             -- the LEFT(...) truncation below ever gets a chance to run.
BEGIN
    SELECT GREATEST(
        (SELECT MAX(date_trunc('month', event_dt))::date FROM bl_dm.fct_transactions_dd),
        (SELECT MAX(date_trunc('month', t.transaction_date))::date
           FROM bl_3nf.ce_transaction t
           WHERE t.transaction_sk <> -1)
    ) INTO v_current_month;

    IF v_current_month IS NULL THEN
        CALL bl_cl.prc_log_etl_event('PRC_MANAGE_FCT_PARTITIONS', v_start_ts, 0, 'SUCCESS', 'nothing to do -- no transactions yet');
        RETURN;
    END IF;

    v_cutoff := (v_current_month - (p_window_months - 1) * INTERVAL '1 month')::date;

    -- 1. Make sure every month INSIDE the current window that still has
    -- BL_3NF rows waiting to be loaded into BL_DM already has a partition
    -- attached. The window guard on this loop avoids attaching (and then
    -- immediately detaching) partitions for months far outside the
    -- window on a big first load.
    FOR v_month IN
        SELECT DISTINCT date_trunc('month', t.transaction_date)::date
        FROM bl_3nf.ce_transaction t
        WHERE t.transaction_sk <> -1
          AND date_trunc('month', t.transaction_date)::date >= v_cutoff
          AND NOT EXISTS (
              SELECT 1 FROM bl_dm.fct_transactions_dd f
              WHERE f.transaction_src_id = t.transaction_id::VARCHAR(50) AND f.event_dt = t.transaction_date
          )
        ORDER BY 1
    LOOP
        v_part_name := 'fct_transactions_dd_' || to_char(v_month, 'YYYY_MM');
        IF NOT EXISTS (
            SELECT 1 FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE n.nspname = 'bl_dm' AND c.relname = v_part_name
        ) THEN
            EXECUTE format('CREATE TABLE bl_dm.%I (LIKE bl_dm.fct_transactions_dd INCLUDING ALL)', v_part_name);
            EXECUTE format(
                'ALTER TABLE bl_dm.fct_transactions_dd ATTACH PARTITION bl_dm.%I FOR VALUES FROM (%L) TO (%L)',
                v_part_name, v_month, (v_month + INTERVAL '1 month')::date
            );
            v_created := v_created || v_part_name || ' ';
            v_created_count := v_created_count + 1;
            v_count := v_count + 1;
        END IF;
    END LOOP;

    -- 2. Detach (not drop) any monthly partition older than the window.
    -- Kept as a plain standalone table afterwards, so it can still be
    -- queried, archived or reported on later.
    FOR v_rec IN
        SELECT c.relname,
               to_date(substring(c.relname FROM 'fct_transactions_dd_(\d{4}_\d{2})$'), 'YYYY_MM') AS part_month
        FROM pg_inherits i
        JOIN pg_class c   ON c.oid = i.inhrelid
        JOIN pg_class p   ON p.oid = i.inhparent
        JOIN pg_namespace n ON n.oid = p.relnamespace
        WHERE n.nspname = 'bl_dm' AND p.relname = 'fct_transactions_dd'
          AND c.relname <> 'fct_transactions_dd_default'
    LOOP
        IF v_rec.part_month < v_cutoff THEN
            EXECUTE format('ALTER TABLE bl_dm.fct_transactions_dd DETACH PARTITION bl_dm.%I', v_rec.relname);
            v_detached := v_detached || v_rec.relname || ' ';
            v_detached_count := v_detached_count + 1;
            v_count := v_count + 1;
        END IF;
    END LOOP;

    v_message := format('window=%s months, current_month=%s, cutoff=%s, attached=%s partition(s) [%s], detached=%s partition(s) [%s]',
                         p_window_months, v_current_month, v_cutoff,
                         v_created_count, v_created, v_detached_count, v_detached);
    IF length(v_message) > 1000 THEN
        v_message := left(v_message, 997) || '...';
    END IF;

    CALL bl_cl.prc_log_etl_event('PRC_MANAGE_FCT_PARTITIONS', v_start_ts, v_count, 'SUCCESS', v_message);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_MANAGE_FCT_PARTITIONS', v_start_ts, v_count, 'FAILED', SQLERRM);
        RAISE;
END;
$$;


-- =======================================================================
-- PRC_LOAD_FCT_TRANSACTIONS_DD
-- Incremental load of the fact table on the DM (star schema) layer.
-- Always calls PRC_MANAGE_FCT_PARTITIONS first, so the right monthly
-- partitions exist before the INSERT runs. Every dimension surrogate key
-- is resolved via LEFT JOIN + COALESCE(..., -1); CUSTOMER_SURR_ID is
-- resolved "as of" EVENT_DT against DIM_CUSTOMERS_SCD, the same logic
-- used on the 3NF side.
--
-- Bug found and fixed while testing: once a month's partition is
-- DETACHed, its rows are no longer part of BL_DM.FCT_TRANSACTIONS_DD at
-- all -- a plain "WHERE NOT EXISTS" check stops seeing that month's rows
-- and re-inserts all of them as if new. Fixed with the
-- "AND t.transaction_date >= v_cutoff" guard below: once a month has
-- rolled out of the window, this procedure never tries to load it
-- again. The full history is not lost -- it still exists on BL_3NF
-- (never partitioned) and in the detached partition table itself.
-- =======================================================================
CREATE OR REPLACE PROCEDURE bl_cl.prc_load_fct_transactions_dd()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts     TIMESTAMP := clock_timestamp();
    v_rows         INTEGER := 0;
    v_current_month DATE;
    v_cutoff        DATE;
BEGIN
    CALL bl_cl.prc_manage_fct_partitions(3);

    SELECT GREATEST(
        (SELECT MAX(date_trunc('month', event_dt))::date FROM bl_dm.fct_transactions_dd),
        (SELECT MAX(date_trunc('month', t.transaction_date))::date
           FROM bl_3nf.ce_transaction t
           WHERE t.transaction_sk <> -1)
    ) INTO v_current_month;

    v_cutoff := (v_current_month - 2 * INTERVAL '1 month')::date; -- keep in sync with the "3" in prc_manage_fct_partitions(3) above

    INSERT INTO bl_dm.fct_transactions_dd (
        transaction_src_id, event_dt, customer_surr_id, product_surr_id, store_surr_id,
        payment_surr_id, delivery_surr_id, date_surr_id, transaction_channel_cd,
        fct_quantity_num, fct_unit_price_amt, fct_sales_value_amt, fct_discount_amt,
        fct_cost_price_amt, fct_shipping_cost_amt, fct_total_cost_amt, fct_profit_amt,
        fct_avg_unit_cost_amt, insert_dt, update_dt
    )
    SELECT
        t.transaction_id::VARCHAR(50),
        t.transaction_date,
        COALESCE(dcs.customer_surr_id, -1),
        COALESCE(dp.product_surr_id, -1),
        COALESCE(ds.store_surr_id, -1),
        COALESCE(dpay.payment_surr_id, -1),
        COALESCE(ddl.delivery_surr_id, -1),
        COALESCE(dd.date_surr_id, -1),
        t.transaction_channel,
        t.quantity,
        t.unit_price,
        t.sales_value,
        t.discount,
        t.cost_price,
        t.shipping_cost,
        t.total_cost,
        t.profit,
        CASE WHEN t.quantity IS NOT NULL AND t.quantity <> 0
             THEN ROUND(t.total_cost / t.quantity, 2)
             ELSE NULL END,
        CURRENT_DATE,
        CURRENT_DATE
    FROM bl_3nf.ce_transaction t
    JOIN bl_3nf.ce_customer cu  ON cu.customer_sk = t.customer_sk
    JOIN bl_3nf.ce_product  cp  ON cp.product_sk  = t.product_sk
    JOIN bl_3nf.ce_store    cs  ON cs.store_sk    = t.store_sk
    JOIN bl_3nf.ce_payment  cpay ON cpay.payment_sk = t.payment_sk
    JOIN bl_3nf.ce_delivery cd  ON cd.delivery_sk = t.delivery_sk
    LEFT JOIN bl_dm.dim_products      dp   ON dp.product_src_id  = cp.product_id::VARCHAR(50)
    LEFT JOIN bl_dm.dim_stores        ds   ON ds.store_src_id    = cs.store_id::VARCHAR(50)
    LEFT JOIN bl_dm.dim_payments      dpay ON dpay.payment_src_id = cpay.payment_id::VARCHAR(50)
    LEFT JOIN bl_dm.dim_deliveries    ddl  ON ddl.delivery_src_id = cd.delivery_id
    LEFT JOIN bl_dm.dim_dates         dd   ON dd.full_date       = t.transaction_date
    LEFT JOIN bl_dm.dim_customers_scd dcs  ON dcs.customer_src_id = cu.customer_id::VARCHAR(50)
                                           AND t.transaction_date BETWEEN dcs.start_dt AND dcs.end_dt
    WHERE t.transaction_sk <> -1
      AND t.transaction_date >= v_cutoff   -- never re-load a month that has already rolled out of the window
      AND NOT EXISTS (
          SELECT 1 FROM bl_dm.fct_transactions_dd f
          WHERE f.transaction_src_id = t.transaction_id::VARCHAR(50) AND f.event_dt = t.transaction_date
      );

    GET DIAGNOSTICS v_rows = ROW_COUNT;

    CALL bl_cl.prc_log_etl_event('PRC_LOAD_FCT_TRANSACTIONS_DD', v_start_ts, v_rows, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_LOAD_FCT_TRANSACTIONS_DD', v_start_ts, v_rows, 'FAILED', SQLERRM);
        RAISE;
END;
$$;
