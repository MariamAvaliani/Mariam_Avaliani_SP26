-- =======================================================================
-- PRC_LOAD_DIM_CUSTOMERS_SCD
-- The only SCD2 dimension. No ON CONFLICT here on purpose -- an SCD2
-- table must keep every version, so "upsert" is done by hand: close the
-- current DM row with an UPDATE, then INSERT a fresh one, only when the
-- tracked attributes actually changed.
-- Techniques used: cursor FOR loop, composite type (t_customer_attrs)
-- to compare the whole "bundle" of tracked attributes in one IS
-- DISTINCT FROM instead of five separate OR conditions.
-- =======================================================================

DROP TYPE IF EXISTS bl_cl.t_customer_attrs CASCADE;
CREATE TYPE bl_cl.t_customer_attrs AS (
    customer_segment       VARCHAR(50),
    customer_type          VARCHAR(50),
    customer_city          VARCHAR(100),
    customer_loyalty_score INTEGER,
    customer_age_group     VARCHAR(30)
);

CREATE OR REPLACE PROCEDURE bl_cl.prc_load_dim_customers_scd()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts     TIMESTAMP := clock_timestamp();
    v_cur          RECORD;
    v_new_attrs    bl_cl.t_customer_attrs;
    v_old_attrs    bl_cl.t_customer_attrs;
    v_dm_active_id BIGINT;
    v_rows         INTEGER := 0;
BEGIN
    FOR v_cur IN
        SELECT customer_id, customer_segment, customer_type, customer_city, loyalty_score, age_group,
               source_system, source_entity
        FROM bl_3nf.ce_customer
        WHERE is_active = 'Y' AND customer_sk <> -1
    LOOP
        v_new_attrs := ROW(v_cur.customer_segment, v_cur.customer_type, v_cur.customer_city,
                            v_cur.loyalty_score, v_cur.age_group)::bl_cl.t_customer_attrs;

        v_dm_active_id := NULL;
        SELECT customer_surr_id INTO v_dm_active_id
        FROM bl_dm.dim_customers_scd
        WHERE customer_src_id = v_cur.customer_id::VARCHAR(50) AND is_active = 'Y';

        IF v_dm_active_id IS NULL THEN
            -- brand-new customer on BL_DM: first version
            INSERT INTO bl_dm.dim_customers_scd (
                customer_surr_id, customer_src_id, customer_segment, customer_type, customer_city,
                customer_loyalty_score, customer_age_group, start_dt, end_dt, is_active,
                insert_dt, update_dt, source_system, source_entity
            ) VALUES (
                nextval('bl_dm.seq_dim_customers'), v_cur.customer_id::VARCHAR(50),
                (v_new_attrs).customer_segment, (v_new_attrs).customer_type, (v_new_attrs).customer_city,
                (v_new_attrs).customer_loyalty_score, (v_new_attrs).customer_age_group,
                CURRENT_DATE, DATE '9999-12-31', 'Y',
                CURRENT_DATE, CURRENT_DATE, v_cur.source_system, v_cur.source_entity
            );
            v_rows := v_rows + 1;
        ELSE
            v_old_attrs := (
                SELECT ROW(customer_segment, customer_type, customer_city, customer_loyalty_score, customer_age_group)::bl_cl.t_customer_attrs
                FROM bl_dm.dim_customers_scd
                WHERE customer_surr_id = v_dm_active_id
            );

            IF v_old_attrs IS DISTINCT FROM v_new_attrs THEN
                UPDATE bl_dm.dim_customers_scd
                   SET end_dt = (CURRENT_DATE - INTERVAL '1 day')::DATE,
                       is_active = 'N',
                       update_dt = CURRENT_DATE
                 WHERE customer_surr_id = v_dm_active_id;

                INSERT INTO bl_dm.dim_customers_scd (
                    customer_surr_id, customer_src_id, customer_segment, customer_type, customer_city,
                    customer_loyalty_score, customer_age_group, start_dt, end_dt, is_active,
                    insert_dt, update_dt, source_system, source_entity
                ) VALUES (
                    nextval('bl_dm.seq_dim_customers'), v_cur.customer_id::VARCHAR(50),
                    (v_new_attrs).customer_segment, (v_new_attrs).customer_type, (v_new_attrs).customer_city,
                    (v_new_attrs).customer_loyalty_score, (v_new_attrs).customer_age_group,
                    CURRENT_DATE, DATE '9999-12-31', 'Y',
                    CURRENT_DATE, CURRENT_DATE, v_cur.source_system, v_cur.source_entity
                );
                v_rows := v_rows + 2; -- 1 row closed + 1 row opened
            END IF;
            -- ELSE: nothing changed, do nothing -- this is what keeps the
            -- procedure repeatable on unchanged data.
        END IF;
    END LOOP;

    CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_CUSTOMERS_SCD', v_start_ts, v_rows, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_CUSTOMERS_SCD', v_start_ts, v_rows, 'FAILED', SQLERRM);
        RAISE;
END;
$$;
