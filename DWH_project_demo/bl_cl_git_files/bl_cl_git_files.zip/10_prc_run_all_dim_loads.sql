-- =======================================================================
-- PRC_RUN_ALL_DIM_LOADS
-- Task 8 convenience wrapper -- runs every BL_DM dimension load in one
-- CALL, in an order where it does not matter (BL_DM dimensions have no
-- FKs between each other -- every dimension is independently
-- flattened). Calls the Task 8, full-scan PRC_LOAD_DIM_PAYMENTS, not
-- the Task 9 incremental version -- kept exactly as originally built,
-- still callable on its own; PRC_RUN_ALL_LOADS (the full pipeline) uses
-- the incremental payments load instead.
-- Has its own MTA_ETL_LOG entry and EXCEPTION handler: without this, a
-- failure inside any of the called procedures would abort the wrapper
-- silently at the pipeline level, even though the individual procedure
-- already logged its own failure.
-- =======================================================================
CREATE OR REPLACE PROCEDURE bl_cl.prc_run_all_dim_loads()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts TIMESTAMP := clock_timestamp();
BEGIN
    CALL bl_cl.prc_load_dim_products();
    CALL bl_cl.prc_load_dim_stores();
    CALL bl_cl.prc_load_dim_payments();
    CALL bl_cl.prc_load_dim_deliveries();
    CALL bl_cl.prc_load_dim_customers_scd();

    CALL bl_cl.prc_log_etl_event('PRC_RUN_ALL_DIM_LOADS', v_start_ts, 0, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_RUN_ALL_DIM_LOADS', v_start_ts, 0, 'FAILED', SQLERRM);
        RAISE;
END;
$$;
