-- =====================================================================
-- BL_CL logging infrastructure.
-- MTA_ETL_LOG (metadata table, per Naming_Conventions.docx --
-- "Metadata tables -> MTA_<Name in Plural>") + the one procedure that
-- is the only way to write into it. Every other BL_CL procedure calls
-- this one, on both its success path and its EXCEPTION handler.
-- =====================================================================

CREATE SEQUENCE IF NOT EXISTS bl_cl.seq_mta_etl_log;

CREATE TABLE IF NOT EXISTS bl_cl.mta_etl_log (
    log_id          BIGINT       NOT NULL,
    procedure_name  VARCHAR(100) NOT NULL,
    start_ts        TIMESTAMP    NOT NULL,
    end_ts          TIMESTAMP    NOT NULL,
    rows_affected   INTEGER      NOT NULL,
    status          VARCHAR(20)  NOT NULL,
    message         VARCHAR(1000),
    CONSTRAINT pk_mta_etl_log PRIMARY KEY (log_id),
    CONSTRAINT ck_mta_etl_log_status CHECK (status IN ('SUCCESS', 'FAILED'))
);

CREATE OR REPLACE PROCEDURE bl_cl.prc_log_etl_event(
    p_procedure_name VARCHAR,
    p_start_ts       TIMESTAMP,
    p_rows_affected  INTEGER,
    p_status         VARCHAR,
    p_message        VARCHAR DEFAULT NULL
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO bl_cl.mta_etl_log (log_id, procedure_name, start_ts, end_ts, rows_affected, status, message)
    VALUES (nextval('bl_cl.seq_mta_etl_log'), p_procedure_name, p_start_ts, clock_timestamp(), p_rows_affected, p_status, p_message);
END;
$$;
