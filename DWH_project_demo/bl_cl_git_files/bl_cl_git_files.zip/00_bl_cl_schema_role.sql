-- =====================================================================
-- BL_CL -- schema, role and grants.
-- Run this first, once, before any of the procedure files below.
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS bl_cl;

-- ---------------------------------------------------------------------
-- Role that represents the Cleansing Layer at runtime. All BL_CL
-- procedures run as this role (or a user granted this role), so the
-- grants control exactly what the ETL layer is allowed to touch:
-- read-only on BL_3NF, read/write on BL_DM and BL_CL, and the ability
-- to run the BL_CL procedures themselves.
-- ---------------------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'bl_cl_role') THEN
        CREATE ROLE bl_cl_role NOLOGIN;
    END IF;
END $$;

GRANT USAGE ON SCHEMA bl_3nf TO bl_cl_role;
GRANT SELECT ON ALL TABLES IN SCHEMA bl_3nf TO bl_cl_role;

GRANT USAGE ON SCHEMA bl_dm TO bl_cl_role;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA bl_dm TO bl_cl_role;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA bl_dm TO bl_cl_role;

GRANT USAGE ON SCHEMA bl_cl TO bl_cl_role;
