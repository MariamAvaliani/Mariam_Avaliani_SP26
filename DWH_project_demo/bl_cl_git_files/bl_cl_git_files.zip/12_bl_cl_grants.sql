-- =======================================================================
-- BL_CL -- closing grants.
-- Run this last, after every procedure/table file above has been run.
--
-- 00_bl_cl_schema_role.sql already grants USAGE + basic access on
-- BL_3NF and BL_DM, plus USAGE on the BL_CL schema itself. The grants
-- below are repeated/added here on purpose: BL_CL.MTA_ETL_LOG and the
-- procedures did not exist yet when 00_bl_cl_schema_role.sql ran, so
-- "ALL TABLES" / "ALL PROCEDURES" in that file could not have covered
-- them. The ALTER DEFAULT PRIVILEGES lines also make sure that any
-- table, sequence or procedure added to BL_CL later is automatically
-- covered too, without editing a grants file again.
-- =======================================================================

GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA bl_cl TO bl_cl_role;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA bl_cl TO bl_cl_role;
GRANT EXECUTE ON ALL PROCEDURES IN SCHEMA bl_cl TO bl_cl_role;

ALTER DEFAULT PRIVILEGES IN SCHEMA bl_cl GRANT SELECT, INSERT, UPDATE ON TABLES TO bl_cl_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA bl_cl GRANT USAGE ON SEQUENCES TO bl_cl_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA bl_cl GRANT EXECUTE ON ROUTINES TO bl_cl_role;
