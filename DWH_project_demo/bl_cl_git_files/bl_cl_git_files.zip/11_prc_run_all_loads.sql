-- =======================================================================
-- PRC_RUN_ALL_LOADS
-- Task 9 -- the actual end-to-end pipeline entry point. One CALL to this
-- procedure runs the whole thing in the correct order:
--   1. PRC_REFRESH_BL_3NF        -- staging -> BL_3NF (3NF layer refresh)
--   2. PRC_LOAD_CE_TRANSACTION   -- BL_3NF transaction bridge/CE table
--   3. PRC_LOAD_DIM_PRODUCTS
--   4. PRC_LOAD_DIM_STORES
--   5. PRC_LOAD_DIM_PAYMENTS_INCR -- incremental version, not the full scan
--   6. PRC_LOAD_DIM_DELIVERIES
--   7. PRC_LOAD_DIM_CUSTOMERS_SCD -- SCD2
--   8. PRC_LOAD_FCT_TRANSACTIONS_DD -- partitions managed, then fact rows loaded
-- This is the exact source confirmed live on the database with
-- pg_get_functiondef, not a locally-edited copy -- an earlier local copy
-- of this file was missing the PRC_REFRESH_BL_3NF call, which turned out
-- to just be a stale, never-updated file and not a real gap in the
-- pipeline itself.
-- =======================================================================
CREATE OR REPLACE PROCEDURE bl_cl.prc_run_all_loads()
 LANGUAGE plpgsql
AS $procedure$
DECLARE
    v_start_ts TIMESTAMP := clock_timestamp();
BEGIN
    CALL bl_cl.prc_refresh_bl_3nf();
    CALL bl_cl.prc_load_ce_transaction();
    CALL bl_cl.prc_load_dim_products();
    CALL bl_cl.prc_load_dim_stores();
    CALL bl_cl.prc_load_dim_payments_incr();
    CALL bl_cl.prc_load_dim_deliveries();
    CALL bl_cl.prc_load_dim_customers_scd();
    CALL bl_cl.prc_load_fct_transactions_dd();
    CALL bl_cl.prc_log_etl_event('PRC_RUN_ALL_LOADS', v_start_ts, 0, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_RUN_ALL_LOADS', v_start_ts, 0, 'FAILED', SQLERRM);
        RAISE;
END;
$procedure$;
