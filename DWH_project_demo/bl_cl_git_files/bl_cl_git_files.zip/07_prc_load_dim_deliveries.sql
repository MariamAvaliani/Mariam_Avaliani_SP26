-- =======================================================================
-- PRC_LOAD_DIM_DELIVERIES
-- Techniques used: cursor VARIABLE opened with OPEN ... FOR EXECUTE --
-- the query text itself is assembled at runtime with format() (the
-- source table name is held in a variable), so this is both a cursor
-- variable AND dynamic SQL in the same statement.
-- =======================================================================
CREATE OR REPLACE PROCEDURE bl_cl.prc_load_dim_deliveries()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts   TIMESTAMP := clock_timestamp();
    c_deliveries refcursor;
    v_rec        RECORD;
    v_this       INTEGER;
    v_rows       INTEGER := 0;
    v_src_table  TEXT := 'bl_3nf.ce_delivery';
BEGIN
    OPEN c_deliveries FOR EXECUTE
        format('SELECT delivery_id, delivery_type, delivery_status, fulfillment_time FROM %s WHERE delivery_sk <> -1', v_src_table);

    LOOP
        FETCH c_deliveries INTO v_rec;
        EXIT WHEN NOT FOUND;

        INSERT INTO bl_dm.dim_deliveries (
            delivery_surr_id, delivery_src_id, delivery_type, delivery_status,
            delivery_fulfillment_time_num, insert_dt, update_dt, source_system, source_entity
        ) VALUES (
            nextval('bl_dm.seq_dim_deliveries'), v_rec.delivery_id, v_rec.delivery_type, v_rec.delivery_status,
            v_rec.fulfillment_time, CURRENT_DATE, CURRENT_DATE, 'BL_3NF', 'CE_DELIVERY'
        )
        ON CONFLICT (delivery_src_id) DO UPDATE SET
            delivery_type                  = EXCLUDED.delivery_type,
            delivery_status                = EXCLUDED.delivery_status,
            delivery_fulfillment_time_num  = EXCLUDED.delivery_fulfillment_time_num,
            update_dt                      = CURRENT_DATE
        WHERE dim_deliveries.delivery_type                 IS DISTINCT FROM EXCLUDED.delivery_type
           OR dim_deliveries.delivery_status               IS DISTINCT FROM EXCLUDED.delivery_status
           OR dim_deliveries.delivery_fulfillment_time_num IS DISTINCT FROM EXCLUDED.delivery_fulfillment_time_num;

        GET DIAGNOSTICS v_this = ROW_COUNT;
        v_rows := v_rows + v_this;
    END LOOP;

    CLOSE c_deliveries;

    CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_DELIVERIES', v_start_ts, v_rows, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_DELIVERIES', v_start_ts, v_rows, 'FAILED', SQLERRM);
        RAISE;
END;
$$;
