-- =====================================================================
-- PRC_REFRESH_BL_3NF
-- Refreshes every BL_3NF dimension entity from staging, in dependency
-- order: CE_CATEGORY -> CE_SUBCATEGORY -> CE_PRODUCT,
-- CE_COUNTRY -> CE_REGION -> CE_STORE, CE_CUSTOMER (SCD2), CE_PAYMENT,
-- CE_DELIVERY.
--
-- This one procedure covers nine different BL_3NF tables on purpose --
-- they are refreshed together as a single atomic unit (parents must
-- exist before children resolve their surrogate key), so it is kept as
-- one file/one procedure rather than split further.
--
-- Every hierarchy child resolves its parent surrogate key via
-- LEFT JOIN + COALESCE(parent_sk, -1) -- an unmatched parent points the
-- child at the -1 default row instead of dropping it. Every INSERT is
-- guarded by WHERE NOT EXISTS on the natural key, so re-running this
-- procedure with unchanged staging data inserts nothing new.
-- =====================================================================
CREATE OR REPLACE PROCEDURE bl_cl.prc_refresh_bl_3nf()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts TIMESTAMP := clock_timestamp();
    v_this     INTEGER;
    v_rows     INTEGER := 0;
BEGIN
    -- =================================================================
    -- 1. CE_CATEGORY  (parent of CE_SUBCATEGORY)
    -- =================================================================
    INSERT INTO bl_3nf.ce_category (
        category_sk, category_name, insert_dt, update_dt, source_system, source_entity, source_id
    )
    SELECT
        nextval('bl_3nf.seq_ce_category'),
        dedup.category_name, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
        dedup.source_system, dedup.source_entity, dedup.source_id
    FROM (
        SELECT DISTINCT ON (category_name)
            category_name, source_system, source_entity, source_id
        FROM (
            SELECT product_category AS category_name,
                   'SA_RETAIL' AS source_system, 'SRC_RETAIL_SALES' AS source_entity,
                   product_category AS source_id, 1 AS src_priority
            FROM sa_retail.src_retail_sales
            UNION ALL
            SELECT product_category AS category_name,
                   'SA_ONLINE' AS source_system, 'SRC_ONLINE_SALES' AS source_entity,
                   product_category AS source_id, 2 AS src_priority
            FROM sa_online.src_online_sales
        ) u
        ORDER BY category_name, src_priority
    ) dedup
    WHERE NOT EXISTS (
        SELECT 1 FROM bl_3nf.ce_category c WHERE c.category_name = dedup.category_name
    );
    GET DIAGNOSTICS v_this = ROW_COUNT; v_rows := v_rows + v_this;

    -- =================================================================
    -- 2. CE_SUBCATEGORY  (FK -> CE_CATEGORY)
    -- Natural key is composite (subcategory_name, category_sk).
    -- =================================================================
    INSERT INTO bl_3nf.ce_subcategory (
        subcategory_sk, subcategory_name, category_sk, insert_dt, update_dt, source_system, source_entity, source_id
    )
    SELECT
        nextval('bl_3nf.seq_ce_subcategory'),
        dedup.subcategory_name, COALESCE(cat.category_sk, -1), CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
        dedup.source_system, dedup.source_entity, dedup.source_id
    FROM (
        SELECT DISTINCT ON (subcategory_name, category_name)
            subcategory_name, category_name, source_system, source_entity, source_id
        FROM (
            SELECT product_subcategory AS subcategory_name, product_category AS category_name,
                   'SA_RETAIL' AS source_system, 'SRC_RETAIL_SALES' AS source_entity,
                   product_subcategory AS source_id, 1 AS src_priority
            FROM sa_retail.src_retail_sales
            UNION ALL
            SELECT product_subcategory AS subcategory_name, product_category AS category_name,
                   'SA_ONLINE' AS source_system, 'SRC_ONLINE_SALES' AS source_entity,
                   product_subcategory AS source_id, 2 AS src_priority
            FROM sa_online.src_online_sales
        ) u
        ORDER BY subcategory_name, category_name, src_priority
    ) dedup
    LEFT JOIN bl_3nf.ce_category cat ON cat.category_name = dedup.category_name
    WHERE NOT EXISTS (
        SELECT 1 FROM bl_3nf.ce_subcategory s
        WHERE s.subcategory_name = dedup.subcategory_name AND s.category_sk = COALESCE(cat.category_sk, -1)
    );
    GET DIAGNOSTICS v_this = ROW_COUNT; v_rows := v_rows + v_this;

    -- =================================================================
    -- 3. CE_PRODUCT  (FK -> CE_SUBCATEGORY)
    -- =================================================================
    INSERT INTO bl_3nf.ce_product (
        product_sk, product_id, product_name, subcategory_sk, product_brand, product_price,
        insert_dt, update_dt, source_system, source_entity, source_id
    )
    SELECT
        nextval('bl_3nf.seq_ce_product'),
        dedup.product_id, dedup.product_name, COALESCE(sub.subcategory_sk, -1), dedup.product_brand, dedup.product_price,
        CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, dedup.source_system, dedup.source_entity, dedup.source_id
    FROM (
        SELECT DISTINCT ON (product_id)
            product_id, product_name, product_category, product_subcategory, product_brand, product_price,
            source_system, source_entity, source_id
        FROM (
            SELECT product_id, product_name, product_category, product_subcategory, product_brand, product_price,
                   'SA_RETAIL' AS source_system, 'SRC_RETAIL_SALES' AS source_entity,
                   product_id::VARCHAR(100) AS source_id, 1 AS src_priority
            FROM sa_retail.src_retail_sales
            UNION ALL
            SELECT product_id, product_name, product_category, product_subcategory, product_brand, product_price,
                   'SA_ONLINE' AS source_system, 'SRC_ONLINE_SALES' AS source_entity,
                   product_id::VARCHAR(100) AS source_id, 2 AS src_priority
            FROM sa_online.src_online_sales
        ) u
        ORDER BY product_id, src_priority
    ) dedup
    LEFT JOIN bl_3nf.ce_category cat    ON cat.category_name = dedup.product_category
    LEFT JOIN bl_3nf.ce_subcategory sub ON sub.subcategory_name = dedup.product_subcategory AND sub.category_sk = cat.category_sk
    WHERE NOT EXISTS (
        SELECT 1 FROM bl_3nf.ce_product p WHERE p.product_id = dedup.product_id
    );
    GET DIAGNOSTICS v_this = ROW_COUNT; v_rows := v_rows + v_this;

    -- =================================================================
    -- 4. CE_COUNTRY  (parent of CE_REGION)
    -- =================================================================
    INSERT INTO bl_3nf.ce_country (
        country_sk, country_name, insert_dt, update_dt, source_system, source_entity, source_id
    )
    SELECT
        nextval('bl_3nf.seq_ce_country'),
        dedup.country_name, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
        dedup.source_system, dedup.source_entity, dedup.source_id
    FROM (
        SELECT DISTINCT ON (country_name)
            country_name, source_system, source_entity, source_id
        FROM (
            SELECT country AS country_name,
                   'SA_RETAIL' AS source_system, 'SRC_RETAIL_SALES' AS source_entity,
                   country AS source_id, 1 AS src_priority
            FROM sa_retail.src_retail_sales
            UNION ALL
            SELECT country AS country_name,
                   'SA_ONLINE' AS source_system, 'SRC_ONLINE_SALES' AS source_entity,
                   country AS source_id, 2 AS src_priority
            FROM sa_online.src_online_sales
        ) u
        ORDER BY country_name, src_priority
    ) dedup
    WHERE NOT EXISTS (
        SELECT 1 FROM bl_3nf.ce_country c WHERE c.country_name = dedup.country_name
    );
    GET DIAGNOSTICS v_this = ROW_COUNT; v_rows := v_rows + v_this;

    -- =================================================================
    -- 5. CE_REGION  (FK -> CE_COUNTRY)
    -- The online source has no REGION column at all -- every online row
    -- maps to the 'n. a.' region under its (real) country.
    -- =================================================================
    INSERT INTO bl_3nf.ce_region (
        region_sk, region_name, country_sk, insert_dt, update_dt, source_system, source_entity, source_id
    )
    SELECT
        nextval('bl_3nf.seq_ce_region'),
        dedup.region_name, COALESCE(ctry.country_sk, -1), CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
        dedup.source_system, dedup.source_entity, dedup.source_id
    FROM (
        SELECT DISTINCT ON (region_name, country_name)
            region_name, country_name, source_system, source_entity, source_id
        FROM (
            SELECT COALESCE(region, 'n. a.') AS region_name, country AS country_name,
                   'SA_RETAIL' AS source_system, 'SRC_RETAIL_SALES' AS source_entity,
                   COALESCE(region, 'n. a.') AS source_id, 1 AS src_priority
            FROM sa_retail.src_retail_sales
            UNION ALL
            SELECT 'n. a.' AS region_name, country AS country_name,
                   'SA_ONLINE' AS source_system, 'SRC_ONLINE_SALES' AS source_entity,
                   'n. a.' AS source_id, 2 AS src_priority
            FROM sa_online.src_online_sales
        ) u
        ORDER BY region_name, country_name, src_priority
    ) dedup
    LEFT JOIN bl_3nf.ce_country ctry ON ctry.country_name = dedup.country_name
    WHERE NOT EXISTS (
        SELECT 1 FROM bl_3nf.ce_region r
        WHERE r.region_name = dedup.region_name AND r.country_sk = COALESCE(ctry.country_sk, -1)
    );
    GET DIAGNOSTICS v_this = ROW_COUNT; v_rows := v_rows + v_this;

    -- =================================================================
    -- 6. CE_STORE  (FK -> CE_REGION)
    -- =================================================================
    INSERT INTO bl_3nf.ce_store (
        store_sk, store_id, store_location, store_type, region_sk,
        insert_dt, update_dt, source_system, source_entity, source_id
    )
    SELECT
        nextval('bl_3nf.seq_ce_store'),
        dedup.store_id, dedup.store_location, dedup.store_type, COALESCE(reg.region_sk, -1),
        CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, dedup.source_system, dedup.source_entity, dedup.source_id
    FROM (
        SELECT DISTINCT ON (store_id)
            store_id, store_location, store_type, region_name, country_name,
            source_system, source_entity, source_id
        FROM (
            SELECT store_id, store_location, store_type,
                   COALESCE(region, 'n. a.') AS region_name, country AS country_name,
                   'SA_RETAIL' AS source_system, 'SRC_RETAIL_SALES' AS source_entity,
                   store_id::VARCHAR(100) AS source_id, 1 AS src_priority
            FROM sa_retail.src_retail_sales
            UNION ALL
            SELECT store_id, store_location, store_type,
                   'n. a.' AS region_name, country AS country_name,
                   'SA_ONLINE' AS source_system, 'SRC_ONLINE_SALES' AS source_entity,
                   store_id::VARCHAR(100) AS source_id, 2 AS src_priority
            FROM sa_online.src_online_sales
        ) u
        ORDER BY store_id, src_priority
    ) dedup
    LEFT JOIN bl_3nf.ce_country ctry ON ctry.country_name = dedup.country_name
    LEFT JOIN bl_3nf.ce_region  reg  ON reg.region_name = dedup.region_name AND reg.country_sk = ctry.country_sk
    WHERE NOT EXISTS (
        SELECT 1 FROM bl_3nf.ce_store st WHERE st.store_id = dedup.store_id
    );
    GET DIAGNOSTICS v_this = ROW_COUNT; v_rows := v_rows + v_this;

    -- =================================================================
    -- 7. CE_CUSTOMER (SCD Type 2)
    -- Tracked attributes: customer_segment, customer_type, customer_city,
    -- loyalty_score, age_group.
    --
    -- Mentor feedback on this task: "The SCD2 logic works well for
    -- incremental loads, but it is not designed to reconstruct all
    -- historical versions from a full backfill. This is acceptable for
    -- the current scope and can be left as is." -- the SCD2 mechanism
    -- itself is intentionally left untouched, per that guidance.
    -- =================================================================
    -- 7a. Close the active version of every customer whose tracked
    --     attributes changed since the last load.
    WITH stg_customer AS (
        SELECT DISTINCT ON (customer_id)
            customer_id, customer_segment, customer_type, customer_city,
            loyalty_score, age_group, source_system, source_entity, source_id
        FROM (
            SELECT customer_id, customer_segment, customer_type, customer_city,
                   loyalty_score, age_group, transaction_date,
                   'SA_RETAIL' AS source_system, 'SRC_RETAIL_SALES' AS source_entity,
                   customer_id::VARCHAR(100) AS source_id, 1 AS src_priority, ctid
            FROM sa_retail.src_retail_sales
            UNION ALL
            SELECT customer_id, customer_segment, customer_type, customer_city,
                   loyalty_score, age_group, transaction_date,
                   'SA_ONLINE' AS source_system, 'SRC_ONLINE_SALES' AS source_entity,
                   customer_id::VARCHAR(100) AS source_id, 2 AS src_priority, ctid
            FROM sa_online.src_online_sales
        ) u
        ORDER BY customer_id, transaction_date DESC, src_priority, ctid
    )
    UPDATE bl_3nf.ce_customer c
    SET end_dt    = (CURRENT_DATE - INTERVAL '1 day')::DATE,
        is_active = 'N',
        update_dt = CURRENT_TIMESTAMP
    FROM stg_customer s
    WHERE c.customer_id = s.customer_id
      AND c.is_active = 'Y'
      AND c.customer_sk <> -1                       -- never touch the default row
      AND (    c.customer_segment IS DISTINCT FROM s.customer_segment
            OR c.customer_type    IS DISTINCT FROM s.customer_type
            OR c.customer_city    IS DISTINCT FROM s.customer_city
            OR c.loyalty_score    IS DISTINCT FROM s.loyalty_score
            OR c.age_group        IS DISTINCT FROM s.age_group);
    GET DIAGNOSTICS v_this = ROW_COUNT; v_rows := v_rows + v_this;

    -- 7b. Insert a new active version for brand-new customers, and for
    --     customers whose previous active row was just closed in 7a.
    WITH stg_customer AS (
        SELECT DISTINCT ON (customer_id)
            customer_id, customer_segment, customer_type, customer_city,
            loyalty_score, age_group, source_system, source_entity, source_id
        FROM (
            SELECT customer_id, customer_segment, customer_type, customer_city,
                   loyalty_score, age_group, transaction_date,
                   'SA_RETAIL' AS source_system, 'SRC_RETAIL_SALES' AS source_entity,
                   customer_id::VARCHAR(100) AS source_id, 1 AS src_priority, ctid
            FROM sa_retail.src_retail_sales
            UNION ALL
            SELECT customer_id, customer_segment, customer_type, customer_city,
                   loyalty_score, age_group, transaction_date,
                   'SA_ONLINE' AS source_system, 'SRC_ONLINE_SALES' AS source_entity,
                   customer_id::VARCHAR(100) AS source_id, 2 AS src_priority, ctid
            FROM sa_online.src_online_sales
        ) u
        ORDER BY customer_id, transaction_date DESC, src_priority, ctid
    )
    INSERT INTO bl_3nf.ce_customer (
        customer_sk, customer_id, customer_segment, customer_type, customer_city,
        loyalty_score, age_group, start_dt, end_dt, is_active,
        insert_dt, update_dt, source_system, source_entity, source_id
    )
    SELECT
        nextval('bl_3nf.seq_ce_customer'),
        s.customer_id,
        COALESCE(s.customer_segment, 'n. a.'),
        COALESCE(s.customer_type, 'n. a.'),
        COALESCE(s.customer_city, 'n. a.'),
        COALESCE(s.loyalty_score, -1),
        COALESCE(s.age_group, 'n. a.'),
        CURRENT_DATE,
        DATE '9999-12-31',
        'Y',
        CURRENT_TIMESTAMP,
        CURRENT_TIMESTAMP,
        s.source_system,
        s.source_entity,
        s.source_id
    FROM stg_customer s
    WHERE NOT EXISTS (
        SELECT 1 FROM bl_3nf.ce_customer c
        WHERE c.customer_id = s.customer_id
          AND c.is_active = 'Y'
    );
    GET DIAGNOSTICS v_this = ROW_COUNT; v_rows := v_rows + v_this;

    -- =================================================================
    -- 8. CE_PAYMENT
    -- ASSUMPTION: neither source system has a dedicated payment business
    -- key. Every transaction has exactly one payment event, so
    -- payment_id is derived from transaction_id.
    -- =================================================================
    INSERT INTO bl_3nf.ce_payment (
        payment_sk, payment_id, payment_method, payment_status, payment_risk_score,
        insert_dt, update_dt, source_system, source_entity, source_id
    )
    SELECT
        nextval('bl_3nf.seq_ce_payment'),
        dedup.payment_id, dedup.payment_method, dedup.payment_status, dedup.payment_risk_score,
        CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, dedup.source_system, dedup.source_entity, dedup.source_id
    FROM (
        SELECT DISTINCT ON (payment_id)
            payment_id, payment_method, payment_status, payment_risk_score,
            source_system, source_entity, source_id
        FROM (
            SELECT transaction_id AS payment_id, payment_method, payment_status,
                   ROUND(payment_risk_score)::INTEGER AS payment_risk_score,
                   'SA_RETAIL' AS source_system, 'SRC_RETAIL_SALES' AS source_entity,
                   transaction_id::VARCHAR(100) AS source_id, 1 AS src_priority
            FROM sa_retail.src_retail_sales
            UNION ALL
            SELECT transaction_id AS payment_id, payment_method, payment_status,
                   ROUND(payment_risk_score)::INTEGER AS payment_risk_score,
                   'SA_ONLINE' AS source_system, 'SRC_ONLINE_SALES' AS source_entity,
                   transaction_id::VARCHAR(100) AS source_id, 2 AS src_priority
            FROM sa_online.src_online_sales
        ) u
        ORDER BY payment_id, src_priority
    ) dedup
    WHERE NOT EXISTS (
        SELECT 1 FROM bl_3nf.ce_payment pm WHERE pm.payment_id = dedup.payment_id
    );
    GET DIAGNOSTICS v_this = ROW_COUNT; v_rows := v_rows + v_this;

    -- =================================================================
    -- 9. CE_DELIVERY
    -- Online (e-commerce) transactions only -- the retail channel has no
    -- delivery leg, so retail transactions are simply never inserted
    -- here. They pick up the -1 default row in PRC_LOAD_CE_TRANSACTION.
    -- =================================================================
    INSERT INTO bl_3nf.ce_delivery (
        delivery_sk, delivery_id, delivery_type, delivery_status, fulfillment_time,
        insert_dt, update_dt, source_system, source_entity, source_id
    )
    SELECT
        nextval('bl_3nf.seq_ce_delivery'),
        dedup.delivery_id, dedup.delivery_type, dedup.delivery_status, dedup.fulfillment_time,
        CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, dedup.source_system, dedup.source_entity, dedup.source_id
    FROM (
        SELECT DISTINCT ON (delivery_id)
            transaction_id::VARCHAR(50) AS delivery_id,
            delivery_type, delivery_status, delivery_time AS fulfillment_time,
            'SA_ONLINE' AS source_system, 'SRC_ONLINE_SALES' AS source_entity,
            transaction_id::VARCHAR(100) AS source_id
        FROM sa_online.src_online_sales
    ) dedup
    WHERE NOT EXISTS (
        SELECT 1 FROM bl_3nf.ce_delivery d WHERE d.delivery_id = dedup.delivery_id
    );
    GET DIAGNOSTICS v_this = ROW_COUNT; v_rows := v_rows + v_this;

    -- CE_DATE is intentionally not populated here -- BL_3NF.CE_DATE does
    -- not exist on the real deployed schema. BL_DM.DIM_DATES is
    -- unaffected, it is populated independently of BL_3NF.

    CALL bl_cl.prc_log_etl_event('PRC_REFRESH_BL_3NF', v_start_ts, v_rows, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_REFRESH_BL_3NF', v_start_ts, v_rows, 'FAILED', SQLERRM);
        RAISE;
END;
$$;
