-- =======================================================================
-- PRC_LOAD_DIM_PRODUCTS
-- Techniques used: cursor FOR loop (unbound, over a join query),
-- composite type (t_dim_product_row), EXECUTE for a dynamic upsert
-- statement with USING parameters.
-- The WHERE clause on the ON CONFLICT branch means an unchanged row is
-- skipped (0 rows affected) -- this is what makes the procedure
-- repeatable: run it twice on the same source data and the second run
-- reports 0 rows affected in the log.
-- =======================================================================

DROP TYPE IF EXISTS bl_cl.t_dim_product_row CASCADE;
CREATE TYPE bl_cl.t_dim_product_row AS (
    product_src_id      VARCHAR(50),
    product_name        VARCHAR(255),
    product_category    VARCHAR(100),
    product_subcategory VARCHAR(100),
    product_brand       VARCHAR(100),
    product_price_amt   DECIMAL(12,2),
    source_system       VARCHAR(30),
    source_entity       VARCHAR(50)
);

CREATE OR REPLACE PROCEDURE bl_cl.prc_load_dim_products()
LANGUAGE plpgsql
AS $$
DECLARE
    v_start_ts TIMESTAMP := clock_timestamp();
    v_row      bl_cl.t_dim_product_row;
    v_sql      TEXT;
    v_this     INTEGER;
    v_rows     INTEGER := 0;
BEGIN
    FOR v_row IN
        SELECT
            p.product_id::VARCHAR(50) AS product_src_id,
            p.product_name,
            c.category_name           AS product_category,
            s.subcategory_name        AS product_subcategory,
            p.product_brand,
            p.product_price           AS product_price_amt,
            'BL_3NF'::VARCHAR(30)     AS source_system,
            'CE_PRODUCT'::VARCHAR(50) AS source_entity
        FROM bl_3nf.ce_product p
        JOIN bl_3nf.ce_subcategory s ON s.subcategory_sk = p.subcategory_sk
        JOIN bl_3nf.ce_category c    ON c.category_sk = s.category_sk
        WHERE p.product_sk <> -1
    LOOP
        v_sql := format(
            'INSERT INTO bl_dm.dim_products
                 (product_surr_id, product_src_id, product_name, product_category, product_subcategory,
                  product_brand, product_price_amt, insert_dt, update_dt, source_system, source_entity)
             VALUES (nextval(%L), $1, $2, $3, $4, $5, $6, CURRENT_DATE, CURRENT_DATE, $7, $8)
             ON CONFLICT (product_src_id) DO UPDATE SET
                 product_name        = EXCLUDED.product_name,
                 product_category    = EXCLUDED.product_category,
                 product_subcategory = EXCLUDED.product_subcategory,
                 product_brand       = EXCLUDED.product_brand,
                 product_price_amt   = EXCLUDED.product_price_amt,
                 update_dt           = CURRENT_DATE,
                 source_system       = EXCLUDED.source_system,
                 source_entity       = EXCLUDED.source_entity
             WHERE dim_products.product_name        IS DISTINCT FROM EXCLUDED.product_name
                OR dim_products.product_category    IS DISTINCT FROM EXCLUDED.product_category
                OR dim_products.product_subcategory IS DISTINCT FROM EXCLUDED.product_subcategory
                OR dim_products.product_brand       IS DISTINCT FROM EXCLUDED.product_brand
                OR dim_products.product_price_amt   IS DISTINCT FROM EXCLUDED.product_price_amt',
            'bl_dm.seq_dim_products'
        );

        EXECUTE v_sql USING v_row.product_src_id, v_row.product_name, v_row.product_category,
                             v_row.product_subcategory, v_row.product_brand, v_row.product_price_amt,
                             v_row.source_system, v_row.source_entity;

        GET DIAGNOSTICS v_this = ROW_COUNT;
        v_rows := v_rows + v_this;
    END LOOP;

    CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_PRODUCTS', v_start_ts, v_rows, 'SUCCESS', NULL);
EXCEPTION
    WHEN OTHERS THEN
        CALL bl_cl.prc_log_etl_event('PRC_LOAD_DIM_PRODUCTS', v_start_ts, v_rows, 'FAILED', SQLERRM);
        RAISE;
END;
$$;
